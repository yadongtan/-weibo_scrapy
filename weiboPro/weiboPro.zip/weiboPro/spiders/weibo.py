import scrapy
from copy import deepcopy
from time import sleep
import json
from lxml import etree
import re


class WeiboSpider(scrapy.Spider):
    name = 'weibo'
    #allowed_domains = ['www.weibo.com']
    # allowed_domains = ['www.xxx.com']
    start_urls = ['https://s.weibo.com/top/summary?Refer=top_hot&topnav=1&wvr=6']
    home_page = "https://s.weibo.com/"
    #携带cookie发起请求
    def start_requests(self):
        cookies = "SINAGLOBAL=7445638262810.062.1606393968309; ALF=1637930004; SUB=_2A25yu9Q2DeRhGeBK6lsU8C7EzT-IHXVuR_x-rDV8PUJbkNANLVakkW1NR_ZQG1khNkgy2jTOs1Q367JzGK4beyDf; SUBP=0033WrSXqPxfM725Ws9jqgMF55529P9D9WWA10Xwzs6kWwQ193xmnlOu5NHD95QcSh24SK571hq0Ws4DqcjRi--fiK.XiK.7i--Xi-ihi-8si--RiK.4iKy8i--NiKnEi-z4i--RiKLWiKyWi--4i-2ciK.4IP-t; UOR=,,www.baidu.com; sensorsdata2015jssdkcross=%7B%22distinct_id%22%3A%22176219c8b44960-035bf1e81e9169-c791e37-1327104-176219c8b45af1%22%2C%22%24device_id%22%3A%22176219c8b44960-035bf1e81e9169-c791e37-1327104-176219c8b45af1%22%2C%22props%22%3A%7B%22%24latest_referrer%22%3A%22%22%2C%22%24latest_referrer_host%22%3A%22%22%7D%7D; wvr=6; _s_tentry=www.baidu.com; Apache=5832190066951.724.1609563665954; ULV=1609563666135:11:1:1:5832190066951.724.1609563665954:1606963802593; webim_unReadCount=%7B%22time%22%3A1609564027561%2C%22dm_pub_total%22%3A0%2C%22chat_group_client%22%3A145%2C%22chat_group_notice%22%3A0%2C%22allcountNum%22%3A170%2C%22msgbox%22%3A0%7D"
        #cookies = "SINAGLOBAL=7445638262810.062.1606393968309; ALF=1637930004; wvr=6; SUB=_2A25yu9Q2DeRhGeBK6lsU8C7EzT-IHXVuR_x-rDV8PUJbkNANLVakkW1NR_ZQG1khNkgy2jTOs1Q367JzGK4beyDf; SUBP=0033WrSXqPxfM725Ws9jqgMF55529P9D9WWA10Xwzs6kWwQ193xmnlOu5NHD95QcSh24SK571hq0Ws4DqcjRi--fiK.XiK.7i--Xi-ihi-8si--RiK.4iKy8i--NiKnEi-z4i--RiKLWiKyWi--4i-2ciK.4IP-t; UOR=,,www.baidu.com; wb_view_log_6419500863=1536*8641.25; _s_tentry=www.baidu.com; Apache=1002481459153.9855.1606833584581; ULV=1606833584640:4:3:3:1002481459153.9855.1606833584581:1606833437232; webim_unReadCount=%7B%22time%22%3A1606834521053%2C%22dm_pub_total%22%3A0%2C%22chat_group_client%22%3A62%2C%22chat_group_notice%22%3A0%2C%22allcountNum%22%3A92%2C%22msgbox%22%3A0%7D"
        cookies = {i.split("=")[0]: i.split("=")[1] for i in cookies.split("; ")}
        yield scrapy.Request(
            self.start_urls[0],
            callback=self.parse,
            cookies=cookies
        )

    #分析热搜和链接
    def parse(self, response, **kwargs):
        page_text = response.text
        with open('first.html','w',encoding='utf-8') as fp:
            fp.write(page_text)
        item = {}
        tr = response.xpath('//*[@id="pl_top_realtimehot"]/table//tr')[1:]
        #print(tr)
        for t in tr:
            item['title'] = t.xpath('./td[2]//text()').extract()[1]
            print('title : ',item['title'])
        #item['domain_id'] = response.xpath('//input[@id="sid"]/@value').get()
        #item['description'] = response.xpath('//div[@id="description"]').get()
            detail_url = self.home_page + t.xpath('./td[2]//@href').extract_first()
            item['href'] = detail_url
            print("href:",item['href'])

            #print(item)
            #yield item
            yield scrapy.Request(detail_url,callback=self.parse_item, meta={'item':deepcopy(item)})
            # print("parse完成")
            sleep(3)

            #print(item)

#       item{'title':href,}

    #分析每种热搜下的各种首页消息
    def parse_item(self, response, **kwargs):
        # print("开始parse_item")
        item = response.meta['item']
        #print(item)
        div_list = response.xpath('//div[@id="pl_feedlist_index"]//div[@class="card-wrap"]')[1:]
        #print('--------------')
        #print(div_list)
        #details_url_list = []
        #print("div_list : ",div_list)
        #创建名字为标题的文本存储热搜
        name = item['title']
        file_path = './' + name
        for div in div_list:
            author = div.xpath('.//div[@class="info"]/div[2]/a/@nick-name').extract_first()
            brief_con = div.xpath('.//p[@node-type="feed_list_content_full"]//text()').extract()
            if brief_con is None:
                brief_con = div.xpath('.//p[@class="txt"]//text()').extract()
            brief_con = ''.join(brief_con)
            print("brief_con : ",brief_con)
            link = div.xpath('.//p[@class="from"]/a/@href').extract_first()

            if author is None or link is None:
                continue
            link = "https:" + link + '_&type=comment'
            news_id = div.xpath('./@mid').extract_first()
            print("news_id : ",news_id)
            # print(link)
            news_time = div.xpath(".//p[@class='from']/a/text()").extract()
            news_time = ''.join(news_time)
            print("news_time:", news_time)
            print("author为:",author)
            item['author'] = author
            item['news_id'] = news_id
            item['news_time'] = news_time
            item['brief_con'] = brief_con
            item['details_url'] = link
            #json链接模板:https://weibo.com/aj/v6/comment/big?ajwvr=6&id=4577307216321742&from=singleWeiBo
            link = "https://weibo.com/aj/v6/comment/big?ajwvr=6&id="+ news_id + "&from=singleWeiBo"
            # print(link)

            yield scrapy.Request(link,callback=self.parse_detail,meta={'item':deepcopy(item)})

        #if response.xpath('.//')

    #print(item)
    #
    #     #https://weibo.com/5263732252/JwvUBxOgt?refer_flag=1001030103_&type=comment#_rnd1606842923407
    #     #https://weibo.com/5477984152/JwvVejOnC?refer_flag=1001030103_&type=comment#_rnd1606842895922
    #             details_url = response.xpath('//div[@class="content"]/p[@class="from"]/a/@href').extract_first()
    #             print(details_url)
    #             item['details_url'] = details_url
    #             yield scrapy.Request(details_url, callback=self.parse_detail, meta={'item': deepcopy(item)})
    #             sleep(3)
    #

    #分析每条消息的详情和评论
    #https://weibo.com/1649173367/JwjbPDW00?refer_flag=1001030103__&type=comment
    #json数据包
    #https://weibo.com/aj/v6/comment/big?ajwvr=6&id=4577307216321742&from=singleWeiBo&__rnd=1606879908312
    def parse_detail(self, response, **kwargs):
        # print("status:",response.status)
        # print("ur;:",response.url)
        # print("request:",response.request)
        # print("headers:",response.headers)
        # #print(response.text)
        # print("parse_detail开始")
        item = response.meta['item']
        all= json.loads(response.text)['data']['html']
        # #print(all)
        with open('3.html','w',encoding='utf-8') as fp:
            fp.write(all)
        tree = etree.HTML(all)
        # print(type(tree))
        # username = tree.xpath('//div[@class="list_con"]/div[@class="WB_text"]/a[1]/text()')
        # usertime = re.findall('<div class="WB_from S_txt2">(.*?)</div>', all)
        # comment = tree.xpath('//div[@class="list_con"]/div[@class="WB_text"]//text()')
        # print(usertime)
        # #因为评论前有个中文的引号,正则格外的好用
        # #comment = re.findall(r'</a>：(.*?)<',all)
        # for i in comment:
        #     for w in i:
        #         if i == "\\n":
        #             comment.pop(i)
        #             break
        # with open("12.txt","w",encoding='utf-8') as fp:
        #     for i in comment:
        #         fp.write(i)
        # print(comment)
        #95-122
        div_lists = tree.xpath('.//div[@class="list_con"]')
        final_lists = []
        #print(div_lists)

        with open('13.txt', 'a', encoding='utf-8') as fp:
            for div in div_lists:
                list = []
                username = div.xpath('./div[@class="WB_text"]/a[1]/text()')[0]
                usertime = div.xpath('.//div[@class="WB_from S_txt2"]/text()')[0]
                usercontent = div.xpath('./div[@class="WB_text"]/text()')
                str = usertime + '\n' + username
                #print(username,usertime,usercontent)
                # fp.write(usertime + '\n' + username)
                for con in usercontent[1:]:
                    str += '\n' + username + '\n' + usertime + '\n' + con + '\n'
                #
                usercontent = ''.join(usercontent)
                #print('usercontent:',usercontent)
                item['username'] = username
                item['usertime'] = usertime
                item['usercontent'] = usercontent
                list.append(username)
                list.append(usertime)
                list.append(usercontent)
                final_lists.append(list)
                #item['user'] = [username,usertime,usercontent]

            item['user'] = final_lists
            yield item
